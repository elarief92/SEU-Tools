# Deployment Guide for SEU Tools Django Application

This guide provides detailed instructions for deploying the SEU Tools Django web application on both Windows and Linux servers.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Windows Deployment](#windows-deployment)
- [Linux Deployment](#linux-deployment)
- [Environment Configuration](#environment-configuration)
- [Production Best Practices](#production-best-practices)
- [Troubleshooting](#troubleshooting)

## Prerequisites

### Required Software
- Python 3.8 or higher
- Git
- pip (Python package manager)
- A production-grade WSGI server (e.g., Gunicorn for Linux or Waitress for Windows)
- A reverse proxy (e.g., Nginx or Apache)
- PostgreSQL (recommended for production)

### System Requirements
- Minimum 2GB RAM
- 2 CPU cores
- 10GB available disk space
- Internet connectivity for package installation

### Dependencies Overview
```plaintext
# Django and related packages
django==4.2.7
djangorestframework==3.14.0
python-decouple==3.8

# PDF Processing
pdfplumber==0.11.7

# Authentication and Security
python-jose[cryptography]==3.5.0
passlib[bcrypt]==1.7.4
bcrypt==4.3.0
PyJWT==2.8.0

# Environment and Configuration
python-dotenv==1.0.1

# Azure OpenAI
openai==1.93.2
```

## Windows Deployment

### 1. Install Required Software

1. **Install Python 3.8+**:
   ```powershell
   # Download Python from official website
   # https://www.python.org/downloads/
   # During installation, check "Add Python to PATH"
   ```

2. **Install Git**:
   ```powershell
   # Download from https://git-scm.com/download/win
   # Use default installation options
   ```

### 2. Setup Application

1. **Clone Repository**:
   ```powershell
   # Create application directory
   mkdir C:\apps
   cd C:\apps
   git clone <repository-url> seu-tools
   cd seu-tools
   ```

2. **Create Virtual Environment**:
   ```powershell
   python -m venv venv
   .\venv\Scripts\activate
   ```

3. **Install Dependencies**:
   ```powershell
   pip install -r requirements.txt
   pip install waitress  # Windows production server
   ```

### 3. Configure Environment

1. **Create `.env` File**:
   ```powershell
   copy .env.example .env
   # Edit .env with appropriate values
   ```

2. **Database Setup**:
   ```powershell
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py collectstatic
   ```

### 4. Setup Windows Service

1. **Create Service Script** (`run_app.ps1`):
   ```powershell
   # Create file: C:\apps\seu-tools\run_app.ps1
   Set-Location C:\apps\seu-tools
   .\venv\Scripts\activate
   $env:PYTHONPATH = "C:\apps\seu-tools"
   waitress-serve --host=127.0.0.1 --port=8000 seu_tools.wsgi:application
   ```

2. **Create Windows Service**:
   ```powershell
   # Using NSSM (Non-Sucking Service Manager)
   # Download NSSM from https://nssm.cc/
   nssm install SEUToolsService "powershell" "C:\apps\seu-tools\run_app.ps1"
   nssm set SEUToolsService AppDirectory "C:\apps\seu-tools"
   nssm set SEUToolsService Description "SEU Tools Django Application Service"
   nssm start SEUToolsService
   ```

## Linux Deployment

### 1. Install Required Software

1. **Update System**:
   ```bash
   sudo apt update && sudo apt upgrade -y  # For Ubuntu/Debian
   # OR
   sudo yum update -y  # For CentOS/RHEL
   ```

2. **Install Python and Dependencies**:
   ```bash
   # Ubuntu/Debian
   sudo apt install -y python3 python3-venv python3-pip git nginx postgresql postgresql-contrib

   # CentOS/RHEL
   sudo yum install -y python3.8 python3-pip git nginx postgresql postgresql-contrib
   ```

### 2. Setup Application

1. **Create Service User**:
   ```bash
   sudo useradd -r -s /bin/false seu-tools
   sudo mkdir /opt/seu-tools
   sudo chown seu-tools:seu-tools /opt/seu-tools
   ```

2. **Clone Repository**:
   ```bash
   sudo -u seu-tools git clone <repository-url> /opt/seu-tools
   cd /opt/seu-tools
   ```

3. **Create Virtual Environment**:
   ```bash
   sudo -u seu-tools python3.8 -m venv venv
   source venv/bin/activate
   ```

4. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   pip install gunicorn
   ```

### 3. Configure Environment

1. **Create `.env` File**:
   ```bash
   sudo -u seu-tools cp .env.example .env
   sudo -u seu-tools nano .env
   ```

2. **Database Setup**:
   ```bash
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py collectstatic
   ```

### 4. Setup Systemd Service

1. **Create Service File**:
   ```bash
   sudo nano /etc/systemd/system/seu-tools.service
   ```

   Content:
   ```ini
   [Unit]
   Description=SEU Tools Django Application
   After=network.target

   [Service]
   User=seu-tools
   Group=seu-tools
   WorkingDirectory=/opt/seu-tools
   Environment="PATH=/opt/seu-tools/venv/bin"
   ExecStart=/opt/seu-tools/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:8000 seu_tools.wsgi:application
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```

### 5. Configure Nginx Reverse Proxy

1. **Create Nginx Configuration**:
   ```bash
   sudo nano /etc/nginx/sites-available/seu-tools
   ```

   Content:
   ```nginx
   server {
       listen 80;
       server_name your_domain.com;

       location / {
           proxy_pass http://127.0.0.1:8000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }
   }
   ```

2. **Enable Site and Configure File Upload Limits**:
   ```bash
   sudo ln -s /etc/nginx/sites-available/seu-tools /etc/nginx/sites-enabled/
   
   # Configure file upload size limit (50MB) for certificate processing
   sudo sed -i '/server_name/a\    client_max_body_size 50M;' /etc/nginx/sites-available/seu-tools
   
   sudo nginx -t
   sudo systemctl restart nginx
   ```

## Environment Configuration

### Required Environment Variables

Update your `.env` file with production values:

```env
# Security Settings
SECRET_KEY=<your-generated-secret-key>
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Authentication
ADMIN_USERNAME=<production-admin-username>
ADMIN_PASSWORD=<strong-production-password>

# Server Settings
HOST=127.0.0.1
PORT=8000
WORKERS=4

# CORS Settings
ALLOWED_ORIGINS=https://your-domain.com

# Allowed IP Addresses
ALLOWED_IPS=<production-ip-ranges>

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=%(asctime)s - %(name)s - %(levelname)s - %(message)s

# PDF Processing
MIN_SUBSCRIPTION_MONTHS=170
MAX_SUBSCRIPTION_MONTHS=180
```

## Production Best Practices

### Security

1. **SSL/TLS Configuration**:
   - Always use HTTPS in production
   - Install SSL certificate (Let's Encrypt recommended)
   - Configure SSL in Nginx

2. **Firewall Configuration**:
   ```bash
   # Ubuntu/Debian
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   sudo ufw enable

   # CentOS/RHEL
   sudo firewall-cmd --permanent --add-service=http
   sudo firewall-cmd --permanent --add-service=https
   sudo firewall-cmd --reload
   ```

3. **Regular Updates**:
   ```bash
   # Update system packages weekly
   # Update Python packages monthly
   # Rotate logs regularly
   ```

### Monitoring

1. **Setup Basic Monitoring**:
   ```bash
   # Install monitoring tools
   sudo apt install -y prometheus node-exporter
   # OR
   sudo yum install -y prometheus node-exporter
   ```

2. **Configure Log Rotation**:
   ```bash
   sudo nano /etc/logrotate.d/seu-tools
   ```

   Content:
   ```
   /var/log/seu-tools/*.log {
       daily
       rotate 14
       compress
       delaycompress
       notifempty
       create 0640 seu-tools seu-tools
       sharedscripts
       postrotate
           systemctl reload seu-tools
       endscript
   }
   ```

### Backup

1. **Setup Daily Backups**:
   ```bash
   # Create backup script
   sudo nano /opt/seu-tools/backup.sh
   ```

   Content:
   ```bash
   #!/bin/bash
   BACKUP_DIR="/backup/seu-tools"
   DATE=$(date +%Y%m%d)
   mkdir -p $BACKUP_DIR
   
   # Backup application files
   tar -czf $BACKUP_DIR/seu-tools-$DATE.tar.gz /opt/seu-tools
   
   # Backup environment file separately
   cp /opt/seu-tools/.env $BACKUP_DIR/env-$DATE.bak
   
   # Remove backups older than 7 days
   find $BACKUP_DIR -type f -mtime +7 -delete
   ```

2. **Schedule Backup**:
   ```bash
   sudo chmod +x /opt/seu-tools/backup.sh
   sudo crontab -e
   # Add: 0 2 * * * /opt/seu-tools/backup.sh
   ```

## Troubleshooting

### Common Issues

1. **Service Won't Start**:
   - Check logs: `sudo journalctl -u seu-tools -n 100`
   - Verify permissions: `ls -la /opt/seu-tools`
   - Check Python path: `which python3`

2. **Permission Issues**:
   ```bash
   sudo chown -R seu-tools:seu-tools /opt/seu-tools
   sudo chmod -R 755 /opt/seu-tools
   sudo chmod 600 /opt/seu-tools/.env
   ```

3. **Nginx 502 Bad Gateway**:
   - Check if gunicorn is running: `ps aux | grep gunicorn`
   - Check Nginx logs: `sudo tail -f /var/log/nginx/error.log`
   - Verify Nginx configuration: `sudo nginx -t`

### Maintenance Commands

1. **Restart Services**:
   ```bash
   # Linux
   sudo systemctl restart seu-tools
   sudo systemctl restart nginx

   # Windows
   nssm restart SEUToolsService
   ```

2. **View Logs**:
   ```bash
   # Linux
   sudo journalctl -u seu-tools -f
   sudo tail -f /var/log/nginx/access.log

   # Windows
   Get-EventLog -LogName Application -Source SEUToolsService
   ```

3. **Update Application**:
   ```bash
   # Linux
   cd /opt/seu-tools
   sudo -u seu-tools git pull
   source venv/bin/activate
   pip install -r requirements.txt
   sudo systemctl restart seu-tools

   # Windows
   cd C:\apps\seu-tools
   git pull
   .\venv\Scripts\activate
   pip install -r requirements.txt
   nssm restart SEUToolsService
   ```

For additional support or questions, please contact the development team or refer to the project's documentation. 